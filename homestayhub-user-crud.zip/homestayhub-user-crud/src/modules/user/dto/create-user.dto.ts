export interface CreateUserDTO {
  email: string;
  password?: string;
  name?: string;
  profileUrl?: string;
}
